module.exports = [
  {
    username: "TB12",
    firstName: "Tom",
    lastName: "Brady",
    age: 41,
    weight: 200,
  },

  {
    username: "cKupp",
    firstName: "Cooper",
    lastName: "Kupp",
    Age: 28,
    Weight: 180,
  },
  {
    username: "ScaryTerry",
    firstName: "Terry",
    lastName: "Mclaurin",
    age: 27,
    weight: 195,
  },
  {
    username: "averageJoe",
    firstName: "Joe",
    lastName: "Schmoe",
    age: 24,
    weight: 155,
  },
  {
    username: "DLB",
    firstName: "Dana",
    lastName: "Bailey",
    age: 30,
    weight: 145,
  },
]
