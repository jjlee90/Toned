module.exports = [
  {
    workout: "Push Up",
    sets: 3,
    reps: 20,
    weight: 0,
    user: {
      _id: "62f3fc5cfc5962d7622d35ac",
    },
    date: "2022-08-09T18:06:21.647+00:00",
  },
  {
    workout: "Push Up",
    sets: 3,
    reps: 10,
    weight: 0,
    user: {
      _id: "62f3fc5cfc5962d7622d35ac",
    },
    date: "2022-08-01T18:06:21.647+00:00",
  },
  {
    workout: "Push Up",
    sets: 3,
    reps: 10,
    weight: 0,
    user: {
      _id: "62f3fc5cfc5962d7622d35ac",
    },
    date: "2022-07-28T18:05:21.647+00:00",
  },
  {
    workout: "Push Up",
    sets: 5,
    reps: 5,
    weight: 0,
    user: {
      _id: "62f3fc5cfc5962d7622d35ac",
    },
    date: "2022-07-21T18:12:21.647+00:00",
  },
  {
    workout: "Bench Press",
    sets: 5,
    reps: 1,
    weight: 175,
    user: {
      _id: "62f3fc5cfc5962d7622d35ac",
    },
    date: "2022-08-09T18:01:21.647+00:00",
  },
  {
    workout: "Bench Press",
    sets: 5,
    reps: 3,
    weight: 155,
    user: {
      _id: "62f3fc5cfc5962d7622d35ac",
    },
    date: "2022-08-05T17:05:21.647+00:00",
  },
  {
    workout: "Deadlift",
    sets: 5,
    reps: 5,
    weight: 225,
    user: {
      _id: "62f3fc5cfc5962d7622d35ac",
    },
    date: "2022-07-10T13:01:21.647+00:00",
  },
  {
    workout: "Deadlift",
    sets: 3,
    reps: 8,
    weight: 135,
    user: {
      _id: "62f3fc5cfc5962d7622d35ac",
    },
    date: "2022-07-05T15:01:21.647+00:00",
  },
]
